"use client";

import type { ButtonHTMLAttributes, ReactNode } from "react";

export type WorkflowIconName =
  | "plus"
  | "arrow-left"
  | "refresh"
  | "dashboard"
  | "request"
  | "edit"
  | "approval"
  | "shield"
  | "attachment"
  | "money"
  | "timeline"
  | "search"
  | "view";

export function WorkflowIcon({ name, className = "h-5 w-5" }: { name: WorkflowIconName; className?: string }) {
  const common = { fill: "none", stroke: "currentColor", strokeWidth: 1.9, strokeLinecap: "round" as const, strokeLinejoin: "round" as const };
  const paths: Record<WorkflowIconName, ReactNode> = {
    plus: <><path d="M12 5v14M5 12h14" /></>,
    "arrow-left": <><path d="m15 18-6-6 6-6" /><path d="M9 12h10" /></>,
    refresh: <><path d="M20 11a8 8 0 1 0-2.3 5.7" /><path d="M20 4v7h-7" /></>,
    dashboard: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
    request: <><path d="M7 3h8l4 4v14H7z" /><path d="M15 3v5h5" /><path d="M10 13h6M10 17h6" /></>,
    edit: <><path d="M12 20h9" /><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z" /></>,
    approval: <><path d="M9 11l2 2 4-4" /><path d="M12 22c5-2 8-6 8-11V5l-8-3-8 3v6c0 5 3 9 8 11Z" /></>,
    shield: <><path d="M12 22c5-2 8-6 8-11V5l-8-3-8 3v6c0 5 3 9 8 11Z" /><path d="M9 12l2 2 4-4" /></>,
    attachment: <><path d="m21.4 11.6-8.9 8.9a6 6 0 0 1-8.5-8.5l9.4-9.4a4 4 0 0 1 5.7 5.7L9.7 17.7a2 2 0 0 1-2.8-2.8l8.7-8.7" /></>,
    money: <><rect x="3" y="6" width="18" height="12" rx="2" /><path d="M7 10h.01M17 14h.01" /><circle cx="12" cy="12" r="2" /></>,
    timeline: <><path d="M6 3v18" /><circle cx="6" cy="6" r="2" /><circle cx="6" cy="12" r="2" /><circle cx="6" cy="18" r="2" /><path d="M10 6h8M10 12h8M10 18h8" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    view: <><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z" /><circle cx="12" cy="12" r="2.5" /></>,
  };

  return <svg viewBox="0 0 24 24" aria-hidden="true" className={className} {...common}>{paths[name]}</svg>;
}

export function WorkflowHero({
  eyebrow, title, description, icon, actions, meta,
}: {
  eyebrow: string; title: string; description: string; icon: WorkflowIconName; actions?: ReactNode; meta?: ReactNode;
}) {
  return <header className="rg-module-header"><div className="rg-module-heading"><p className="rg-module-eyebrow"><WorkflowIcon name={icon} className="h-4 w-4"/>{eyebrow}</p><h1>{title}</h1><p className="rg-module-description">{description}</p>{meta?<div className="rg-module-meta">{meta}</div>:null}</div>{actions?<div className="rg-module-actions">{actions}</div>:null}</header>;
}

export function WorkflowAction({
  children,
  icon,
  tone = "blue",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  icon: WorkflowIconName;
  tone?: "blue" | "cyan" | "violet" | "emerald" | "rose" | "white";
}) {
  const tones = {
    blue: "bg-blue-600 text-white hover:bg-blue-500 focus:ring-blue-300/40",
    cyan: "bg-cyan-600 text-white hover:bg-cyan-500 focus:ring-cyan-200/50",
    violet: "bg-violet-600 text-white hover:bg-violet-500 focus:ring-violet-300/40",
    emerald: "bg-emerald-500 text-white hover:bg-emerald-400 focus:ring-emerald-300/40",
    rose: "bg-rose-500 text-white hover:bg-rose-400 focus:ring-rose-300/40",
    white: "border border-white/20 bg-white/10 text-white hover:bg-white/20 focus:ring-white/30",
  };
  return (
    <button
      type="button"
      {...props}
      className={`reqgen-btn reqgen-btn-blue inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-extrabold shadow-sm transition duration-200 hover:-translate-y-0.5 focus:outline-none focus:ring-4 disabled:cursor-not-allowed disabled:opacity-60 ${tones[tone]} ${props.className || ""}`}
    >
      <WorkflowIcon name={icon} className="h-4 w-4" />
      {children}
    </button>
  );
}

export function WorkflowLoading({ title = "Loading workspace..." }: { title?: string }) {
  return <main className="rg-module-page rg-adopted-page"><div className="rg-module-header rg-skeleton-header"/><div className="rg-loading-grid">{Array.from({length:8}).map((_,i)=><div key={i}/>)}</div><div className="rg-section-card"><div className="rg-empty-state"><strong>{title}</strong><p>Preparing your authorised workflow data.</p></div></div></main>;
}

export function WorkflowPageStyles() {
  return (
    <style jsx global>{`
      @keyframes workflowRise { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }
      @keyframes workflowFloat { 0%,100% { transform: translate3d(0,0,0); } 50% { transform: translate3d(0,-10px,0); } }
      .workflow-shell > * { animation: workflowRise .5s ease both; }
      .workflow-shell > *:nth-child(2) { animation-delay: .05s; }
      .workflow-shell > *:nth-child(3) { animation-delay: .1s; }
      .workflow-float { animation: workflowFloat 7s ease-in-out infinite; }
      .workflow-delay { animation-delay: -2.5s; }
      .workflow-shell input:not([type='checkbox']):not([type='radio']),
      .workflow-shell select,
      .workflow-shell textarea { min-height: 46px; border-radius: 14px !important; border-color: rgb(203 213 225) !important; background: rgba(255,255,255,.98) !important; box-shadow: 0 1px 2px rgba(15,23,42,.04); transition: border-color .2s, box-shadow .2s, transform .2s; }
      .workflow-shell input:focus,
      .workflow-shell select:focus,
      .workflow-shell textarea:focus { border-color: rgb(37 99 235) !important; box-shadow: 0 0 0 4px rgba(59,130,246,.12) !important; }
      .workflow-shell button { transition: transform .2s, box-shadow .2s, background-color .2s, border-color .2s; }
      .workflow-shell button:hover:not(:disabled) { transform: translateY(-1px); }
      .workflow-shell .shadow-sm { box-shadow: 0 12px 35px -25px rgba(15,23,42,.45); }
      .workflow-shell .bg-white { background-color: rgba(255,255,255,.97); }
      @media (prefers-reduced-motion: reduce) { .workflow-shell > *, .workflow-float { animation: none !important; } }
    `}</style>
  );
}
