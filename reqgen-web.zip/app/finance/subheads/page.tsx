"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { confirmDialog } from "@/lib/dialog";
import { useRouter } from "next/navigation";
import {
  Eye,
  Pencil,
  MoreVertical,
  Plus,
  Search,
  Filter,
  RefreshCw,
  Download,
  Layers3,
  ShieldCheck,
  PauseCircle,
  GitBranch,
  FolderKanban,
  Network,
  WalletCards,
  AlertCircle,
  X,
  Save,
  Power,
  Trash2,
} from "lucide-react";
import { supabase } from "@/lib/supabaseClient";
import { fetchRequestRegister } from "@/lib/requestRegister";
import { exportTableToExcel } from "@/lib/reportExport";
import styles from "./finance-subheads.module.css";
import { Donut as SharedDonut } from "@/app/components/ui/Donut";

type Dept = {
  id: string;
  name: string;
};

type BankAccount = {
  id: string;
  code: string | null;
  name: string;
  bank_name: string | null;
  is_active: boolean | null;
  total_fund: number | null;
  unallocated_balance: number | null;
  available_balance: number | null;
};

type Subhead = {
  id: string;
  dept_id: string | null;
  bank_account_id: string | null;
  code: string | null;
  name: string;
  approved_allocation: number;
  reserved_amount: number;
  expenditure: number;
  balance: number;
  is_active: boolean;
  updated_at: string | null;
  allocation_note: string | null;
  allocation_date: string | null;
  request_count?: number;
};

type LinkedRequestRow = {
  subhead_id: string | null;
};

type FilterStatus = "all" | "active" | "inactive";
type FilterLevel = "all" | "1" | "2" | "3+";

function errorMessage(error: unknown) {
  return error instanceof Error
    ? error.message
    : "Unknown error";
}

function roleKey(role: string | null | undefined) {
  return (role || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/_/g, "");
}

function money(value: number | null | undefined) {
  return `₦${Number(value || 0).toLocaleString("en-NG", {
    maximumFractionDigits: 0,
  })}`;
}

function subheadLevel(code: string | null | undefined) {
  if (!code) return 1;
  return Math.max(1, code.split(".").length);
}

function parentCode(code: string | null | undefined) {
  if (!code || !code.includes(".")) return null;
  return code.split(".").slice(0, -1).join(".");
}

function formatDate(value: string | null | undefined) {
  if (!value) return "—";

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "—";
  }

  return date.toLocaleDateString("en-GB", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

function getParentLabel(
  subhead: Subhead,
  byCode: Map<string, Subhead>
) {
  const code = parentCode(subhead.code);

  if (!code) {
    return "Top-level head";
  }

  const parent = byCode.get(code);

  return parent
    ? `${parent.code || code} — ${parent.name}`
    : code;
}

export default function FinanceSubheadsPage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  const [role, setRole] = useState("Staff");
  const [userId, setUserId] = useState<string | null>(null);

  const canManage = ["admin", "auditor"].includes(
    roleKey(role)
  );

  const [departments, setDepartments] = useState<Dept[]>([]);
  const [banks, setBanks] = useState<BankAccount[]>([]);
  const [subheads, setSubheads] = useState<Subhead[]>([]);

  const [search, setSearch] = useState("");
  const [categoryFocus, setCategoryFocus] = useState<string | null>(null);
  const [status, setStatus] = useState<FilterStatus>("all");
  const [level, setLevel] = useState<FilterLevel>("all");
  const [parent, setParent] = useState("all");
  const [department, setDepartment] = useState("all");

  const [page, setPage] = useState(1);
  const pageSize = 10;

  const [selected, setSelected] = useState<Subhead | null>(null);

  const [formOpen, setFormOpen] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);

  const [formDept, setFormDept] = useState("");
  const [formBank, setFormBank] = useState("");
  const [formCode, setFormCode] = useState("");
  const [formName, setFormName] = useState("");
  const [formAllocation, setFormAllocation] = useState(0);
  const [formNote, setFormNote] = useState("");
  const [formActive, setFormActive] = useState(true);

  const load = useCallback(
    async (silent = false) => {
      if (silent) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setMessage(null);

      try {
        const { data: auth } =
          await supabase.auth.getUser();

        if (!auth.user) {
          router.push("/login");
          return;
        }

        setUserId(auth.user.id);

        const { data: profile } = await supabase
          .from("profiles")
          .select("role")
          .eq("id", auth.user.id)
          .maybeSingle();

        setRole(
          (profile?.role || "Staff") as string
        );

        await supabase.rpc(
          "reqgen_recalculate_all_iet_accounts"
        );

        const [
          deptRes,
          bankRes,
          subRes,
        ] = await Promise.all([
          supabase
            .from("departments")
            .select("id,name")
            .order("name", {
              ascending: true,
            }),

          supabase
            .from("iet_accounts")
            .select(
              "id,code,name,bank_name,is_active,total_fund,unallocated_balance,available_balance"
            )
            .order("name", {
              ascending: true,
            }),

          supabase
            .from("subheads")
            .select(
              "id,dept_id,bank_account_id,code,name,approved_allocation,reserved_amount,expenditure,balance,is_active,updated_at,allocation_note,allocation_date"
            )
            .order("code", {
              ascending: true,
              nullsFirst: false,
            }),
        ]);

        if (deptRes.error) {
          throw new Error(deptRes.error.message);
        }

        if (bankRes.error) {
          throw new Error(bankRes.error.message);
        }

        if (subRes.error) {
          throw new Error(subRes.error.message);
        }

        const freshSubheads =
          ((subRes.data || []) as Subhead[]).map(
            (item) => ({
              ...item,
              approved_allocation: Number(
                item.approved_allocation || 0
              ),
              reserved_amount: Number(
                item.reserved_amount || 0
              ),
              expenditure: Number(
                item.expenditure || 0
              ),
              balance: Number(
                item.balance || 0
              ),
              is_active:
                item.is_active !== false,
            })
          );

        const requestCountBySubhead: Record<
          string,
          number
        > = {};

        if (freshSubheads.length) {
          // v3.0.4: counts come from the content-free register (all requests,
          // not only the ones this officer may open).
          const { data: registerRows } = await fetchRequestRegister(20000);
          const linkedRows = registerRows.filter((row) => row.subhead_id);

          ((linkedRows || []) as LinkedRequestRow[]).forEach(
            (row) => {
              if (row.subhead_id) {
                requestCountBySubhead[
                  row.subhead_id
                ] =
                  (requestCountBySubhead[
                    row.subhead_id
                  ] || 0) + 1;
              }
            }
          );
        }

        setDepartments(
          (deptRes.data || []) as Dept[]
        );

        setBanks(
          (bankRes.data || []) as BankAccount[]
        );

        setSubheads(
          freshSubheads.map(
            (item) => ({
              ...item,
              request_count:
                requestCountBySubhead[
                item.id
                ] || 0,
            })
          )
        );
      } catch (error: unknown) {
        setMessage(
          `Unable to load finance subheads: ${errorMessage(
            error
          )}`
        );
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [router]
  );

  useEffect(() => {
    queueMicrotask(() => {
      void load();
    });
  }, [load]);

  const departmentMap = useMemo(() => {
    const map = new Map<string, string>();

    departments.forEach((item) => {
      map.set(item.id, item.name);
    });

    return map;
  }, [departments]);

  const bankMap = useMemo(() => {
    const map =
      new Map<string, BankAccount>();

    banks.forEach((item) => {
      map.set(item.id, item);
    });

    return map;
  }, [banks]);

  const byCode = useMemo(() => {
    const map =
      new Map<string, Subhead>();

    subheads.forEach((item) => {
      if (item.code) {
        map.set(
          item.code,
          item
        );
      }
    });

    return map;
  }, [subheads]);

  const parentOptions = useMemo(
    () =>
      subheads.filter(
        (item) =>
          subheadLevel(item.code) === 1 &&
          item.code
      ),
    [subheads]
  );

  const total =
    subheads.length;

  const activeCount =
    subheads.filter(
      (item) =>
        item.is_active
    ).length;

  const inactiveCount =
    total - activeCount;

  const childCount =
    subheads.filter(
      (item) =>
        subheadLevel(
          item.code
        ) > 1
    ).length;

  /** Same grouping as the Subhead Overview chart: the root code's name. */
  const rootLabelOf = useCallback(
    (item: { code?: string | null }) => {
      const root = item.code?.split(".")[0] || "Other";
      return byCode.get(root)?.name || root;
    },
    [byCode]
  );

  const filtered = useMemo(() => {
    const needle =
      search
        .trim()
        .toLowerCase();

    return subheads.filter(
      (item) => {
        if (
          status === "active" &&
          !item.is_active
        ) {
          return false;
        }

        if (
          status === "inactive" &&
          item.is_active
        ) {
          return false;
        }

        const itemLevel =
          subheadLevel(
            item.code
          );

        if (
          level === "1" &&
          itemLevel !== 1
        ) {
          return false;
        }

        if (
          level === "2" &&
          itemLevel !== 2
        ) {
          return false;
        }

        if (
          level === "3+" &&
          itemLevel < 3
        ) {
          return false;
        }

        if (
          department !== "all" &&
          item.dept_id !==
          department
        ) {
          return false;
        }

        if (
          parent !== "all"
        ) {
          const parentValue =
            parentCode(
              item.code
            );

          if (
            item.code !== parent &&
            parentValue !== parent &&
            !item.code?.startsWith(
              `${parent}.`
            )
          ) {
            return false;
          }
        }

        // v3.0.8: chart selection (Subhead Overview donut / legend).
        if (categoryFocus && rootLabelOf(item) !== categoryFocus) {
          return false;
        }

        if (!needle) {
          return true;
        }

        const bank =
          item.bank_account_id
            ? bankMap.get(
              item.bank_account_id
            )
            : null;

        return [
          item.code,
          item.name,
          getParentLabel(
            item,
            byCode
          ),
          item.dept_id
            ? departmentMap.get(
              item.dept_id
            )
            : "",
          bank?.name,
          bank?.bank_name,
          item.is_active
            ? "active"
            : "inactive",
        ]
          .join(" ")
          .toLowerCase()
          .includes(
            needle
          );
      }
    );
  }, [
    subheads,
    search,
    status,
    level,
    department,
    parent,
    categoryFocus,
    rootLabelOf,
    bankMap,
    byCode,
    departmentMap,
  ]);

  useEffect(() => {
    queueMicrotask(() => {
      setPage(1);
    });
  }, [
    search,
    status,
    level,
    department,
    parent,
  ]);

  const totalPages =
    Math.max(
      1,
      Math.ceil(
        filtered.length /
        pageSize
      )
    );

  const safePage =
    Math.min(
      page,
      totalPages
    );

  const paged =
    filtered.slice(
      (safePage - 1) *
      pageSize,
      safePage * pageSize
    );

  const allocationTotal =
    subheads.reduce(
      (sum, item) =>
        sum +
        Number(
          item.approved_allocation ||
          0
        ),
      0
    );

  const categoryData =
    useMemo(() => {
      const groups =
        new Map<
          string,
          number
        >();

      subheads.forEach(
        (item) => {
          const root =
            item.code?.split(
              "."
            )[0] ||
            "Other";

          const rootItem =
            byCode.get(
              root
            );

          const label =
            rootItem?.name ||
            root;

          groups.set(
            label,
            (groups.get(
              label
            ) || 0) + 1
          );
        }
      );

      return [
        ...groups.entries(),
      ]
        .sort(
          (a, b) =>
            b[1] - a[1]
        )
        .slice(
          0,
          5
        )
        .map(
          ([
            label,
            value,
          ]) => ({
            label,
            value,
          })
        );
    }, [
      subheads,
      byCode,
    ]);

  const donutSegments =
    useMemo(() => {
      const colors = [
        "var(--color-chart-1)",
        "var(--color-chart-2)",
        "var(--color-chart-3)",
        "var(--color-chart-4)",
        "var(--color-chart-8)",
      ];
      return categoryData.map((item, index) => ({ label: item.label, value: item.value, color: colors[index] }));
    }, [categoryData]);

  function resetForm() {
    setEditId(null);
    setFormDept("");
    setFormBank("");
    setFormCode("");
    setFormName("");
    setFormAllocation(0);
    setFormNote("");
    setFormActive(true);
  }

  function openCreate() {
    setFormError(null);
    resetForm();
    setFormOpen(true);
  }

  function openEdit(
    item: Subhead
  ) {
    setFormError(null);
    setEditId(item.id);
    setFormDept(
      item.dept_id || ""
    );
    setFormBank(
      item.bank_account_id ||
      ""
    );
    setFormCode(
      item.code || ""
    );
    setFormName(
      item.name
    );
    setFormAllocation(
      Number(
        item.approved_allocation ||
        0
      )
    );
    setFormNote(
      item.allocation_note ||
      ""
    );
    setFormActive(
      item.is_active
    );
    setFormOpen(true);
  }

  async function saveSubhead() {
    if (!canManage) {
      setFormError("Your current role does not allow subhead changes.");
      setMessage("Your current role does not allow subhead changes.");
      return;
    }

    if (!formName.trim()) {
      setFormError("Enter a subhead name.");
      setMessage("Enter a subhead name.");
      return;
    }

    if (!formBank) {
      setFormError("Select the IET Bank funding this subhead.");
      setMessage("Select the IET Bank funding this subhead.");
      return;
    }

    if (
      Number(
        formAllocation
      ) < 0
    ) {
      setFormError("Allocation cannot be negative.");
      setMessage("Allocation cannot be negative.");
      return;
    }

    setSaving(true);
    setMessage(null);
    setFormError(null);

    try {
      const current =
        editId
          ? subheads.find(
            (item) =>
              item.id === editId
          ) || null
          : null;

      const bank =
        bankMap.get(
          formBank
        ) || null;

      const currentAllocation =
        current?.bank_account_id ===
          formBank
          ? Number(
            current.approved_allocation ||
            0
          )
          : 0;

      const availableCapacity =
        Number(
          bank?.unallocated_balance ||
          0
        ) +
        currentAllocation;

      const committed =
        Number(
          current?.reserved_amount ||
          0
        ) +
        Number(
          current?.expenditure ||
          0
        );

      if (
        editId &&
        formAllocation <
        committed
      ) {
        throw new Error(
          `Allocation cannot be below committed amount (${money(
            committed
          )}).`
        );
      }

      if (
        formAllocation >
        availableCapacity
      ) {
        throw new Error(
          `Allocation exceeds available bank capacity (${money(
            availableCapacity
          )}).`
        );
      }

      let subheadId =
        editId;
      let createdThisAttempt = false;

      const payload = {
        dept_id:
          formDept ||
          null,
        code:
          formCode.trim() ||
          null,
        name:
          formName.trim(),
        is_active:
          formActive,
      };

      if (subheadId) {
        const { error } =
          await supabase
            .from("subheads")
            .update(
              payload
            )
            .eq(
              "id",
              subheadId
            );

        if (error) {
          throw new Error(
            error.message
          );
        }
      } else {
        const {
          data,
          error,
        } =
          await supabase
            .from("subheads")
            .insert({
              ...payload,
              bank_account_id:
                null,
              approved_allocation:
                0,
              reserved_amount:
                0,
              expenditure:
                0,
              balance:
                0,
            })
            .select("id")
            .single();

        if (error) {
          throw new Error(
            error.message
          );
        }

        subheadId =
          data.id;
        createdThisAttempt = true;
      }

      const {
        error:
        allocationError,
      } =
        await supabase.rpc(
          "reqgen_assign_subhead_bank_allocation",
          {
            p_subhead_id:
              subheadId,
            p_bank_account_id:
              formBank,
            p_new_allocation:
              Number(
                formAllocation ||
                0
              ),
            p_actor_id:
              userId,
            p_note:
              formNote.trim() ||
              "Updated from Finance Subheads.",
          }
        );

      if (
        allocationError
      ) {
        if (createdThisAttempt && subheadId) {
          await supabase.from("subheads").delete().eq("id", subheadId);
        }
        throw new Error(
          allocationError.message
        );
      }

      setMessage(
        editId
          ? "Subhead updated successfully."
          : "New subhead created successfully."
      );

      setFormOpen(false);
      resetForm();

      await load(true);
    } catch (error: unknown) {
      const raw = error instanceof Error ? error.message : "Unable to save subhead.";
      const friendly = /duplicate|unique/i.test(raw)
        ? "A subhead with this code or name already exists. Review the code/name and try again."
        : /available|capacity|allocation/i.test(raw)
          ? raw
          : `Subhead could not be saved: ${raw}`;
      setFormError(friendly);
      setMessage(friendly);
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(
    item: Subhead
  ) {
    if (!canManage) {
      setMessage("Your current role does not allow subhead changes.");
      return;
    }

    setSaving(true);

    try {
      const { error } =
        await supabase
          .from("subheads")
          .update({
            is_active:
              !item.is_active,
          })
          .eq(
            "id",
            item.id
          );

      if (error) {
        throw new Error(
          error.message
        );
      }

      setMessage(
        item.is_active
          ? "Subhead deactivated."
          : "Subhead activated."
      );

      await load(true);
    } catch (error: unknown) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to update subhead status."
      );
    } finally {
      setSaving(false);
    }
  }

  async function removeUnused(
    item: Subhead
  ) {
    if (!canManage) {
      setFormError("Your current role does not allow subhead changes.");
      setMessage("Your current role does not allow subhead changes.");
      return;
    }

    const linked =
      Number(
        item.request_count ||
        0
      ) > 0 ||
      Number(
        item.approved_allocation ||
        0
      ) > 0 ||
      Number(
        item.reserved_amount ||
        0
      ) > 0 ||
      Number(
        item.expenditure ||
        0
      ) > 0;

    if (linked) {
      setMessage(
        "This subhead has financial or request activity. Deactivate it instead of deleting it."
      );
      return;
    }

    if (
      !(await confirmDialog({
        title: "Delete subhead?",
        message: `Delete unused subhead “${item.name}”?`,
        confirmLabel: "Delete",
        tone: "danger",
      }))
    ) {
      return;
    }

    setSaving(true);

    try {
      const { error } =
        await supabase
          .from("subheads")
          .delete()
          .eq(
            "id",
            item.id
          );

      if (error) {
        throw new Error(
          error.message
        );
      }

      setMessage(
        "Unused subhead deleted."
      );

      await load(true);
    } catch (error: unknown) {
      setMessage(
        error instanceof Error
          ? error.message
          : "Unable to delete subhead."
      );
    } finally {
      setSaving(false);
    }
  }

  async function exportCsv() {
    setExporting(true);

    try {
      exportTableToExcel<Subhead>({
        fileName:
          `finance_subheads_${new Date()
            .toISOString()
            .slice(
              0,
              10
            )}`,

        sheetName:
          "Finance Subheads",

        title:
          "FINANCE SUBHEADS",

        subtitle:
          `${filtered.length} visible subheads | Allocation ${money(
            allocationTotal
          )}`,

        rows:
          filtered,

        columns: [
          {
            header:
              "Code",
            value:
              (row) =>
                row.code ||
                "—",
          },
          {
            header:
              "Subhead",
            value:
              (row) =>
                row.name,
          },
          {
            header:
              "Parent Head",
            value:
              (row) =>
                getParentLabel(
                  row,
                  byCode
                ),
          },
          {
            header:
              "Department",
            value:
              (row) =>
                row.dept_id
                  ? departmentMap.get(
                    row.dept_id
                  ) ||
                  "—"
                  : "—",
          },
          {
            header:
              "Level",
            value:
              (row) =>
                subheadLevel(
                  row.code
                ),
          },
          {
            header:
              "Status",
            value:
              (row) =>
                row.is_active
                  ? "Active"
                  : "Inactive",
          },
          {
            header:
              "Budget",
            value:
              (row) =>
                Number(
                  row.approved_allocation ||
                  0
                ),
          },
          {
            header:
              "Balance",
            value:
              (row) =>
                Number(
                  row.balance ||
                  0
                ),
          },
          {
            header:
              "Updated",
            value:
              (row) =>
                formatDate(
                  row.updated_at
                ),
          },
        ],
      });
    } finally {
      setExporting(false);
    }
  }

  if (loading) {
    return (
      <div className={styles.loading}>
        Loading Finance Subheads…
      </div>
    );
  }

  return (
    <div className={styles.page}>
      <header className={styles.pageHeader}>
        <div>
          <h1>
            Budget & Subheads
          </h1>

          <p>
            Create, manage and organize all finance subheads and budgeting categories.
          </p>
        </div>

        <button
          className={styles.primaryButton}
          onClick={openCreate}
          disabled={!canManage}
        >
          <Plus size={17} />
          Create New Subhead
        </button>
      </header>

      {message ? (
        <div className={styles.messageBar}>
          <span>
            {message}
          </span>

          <button
            onClick={() =>
              setMessage(null)
            }
            aria-label="Dismiss"
          >
            <X size={16} />
          </button>
        </div>
      ) : null}

      <section className={styles.kpiGrid}>
        <Kpi
          icon={<Layers3 size={24} />}
          tone="blue"
          label="Total Subheads"
          value={String(total)}
          note="All Finance Subheads"
        />

        <Kpi
          icon={<ShieldCheck size={24} />}
          tone="green"
          label="Active Subheads"
          value={String(activeCount)}
          note={`${total
              ? (
                (activeCount /
                  total) *
                100
              ).toFixed(
                1
              )
              : "0"
            }% of total subheads`}
        />

        <Kpi
          icon={<PauseCircle size={24} />}
          tone="orange"
          label="Inactive Subheads"
          value={String(inactiveCount)}
          note={`${total
              ? (
                (inactiveCount /
                  total) *
                100
              ).toFixed(
                1
              )
              : "0"
            }% of total subheads`}
        />

        <Kpi
          icon={<GitBranch size={24} />}
          tone="purple"
          label="Under Subheads"
          value={String(childCount)}
          note="Subheads with parent items"
        />
      </section>

      <section className={styles.filterCard}>
        <FilterField
          label="Search Subhead"
          grow
        >
          <div className={styles.searchBox}>
            <Search size={16} />

            <input
              value={search}
              onChange={(event) =>
                setSearch(
                  event.target.value
                )
              }
              placeholder="Search by name, code or description…"
            />
          </div>
        </FilterField>

        <FilterField label="Parent Head">
          <select
            value={parent}
            onChange={(event) =>
              setParent(
                event.target.value
              )
            }
          >
            <option value="all">
              All Parent Heads
            </option>

            {parentOptions.map((item) => (
              <option
                key={item.id}
                value={item.code || ""}
              >
                {item.code} — {item.name}
              </option>
            ))}
          </select>
        </FilterField>

        <FilterField label="Status">
          <select
            value={status}
            onChange={(event) =>
              setStatus(
                event.target.value as FilterStatus
              )
            }
          >
            <option value="all">
              All Statuses
            </option>
            <option value="active">
              Active
            </option>
            <option value="inactive">
              Inactive
            </option>
          </select>
        </FilterField>

        <FilterField label="Level">
          <select
            value={level}
            onChange={(event) =>
              setLevel(
                event.target.value as FilterLevel
              )
            }
          >
            <option value="all">
              All Levels
            </option>
            <option value="1">
              Level 1
            </option>
            <option value="2">
              Level 2
            </option>
            <option value="3+">
              Level 3+
            </option>
          </select>
        </FilterField>

        <FilterField label="Department">
          <select
            value={department}
            onChange={(event) =>
              setDepartment(
                event.target.value
              )
            }
          >
            <option value="all">
              All Departments
            </option>

            {departments.map((item) => (
              <option
                key={item.id}
                value={item.id}
              >
                {item.name}
              </option>
            ))}
          </select>
        </FilterField>

        <button
          className={styles.moreFilters}
          onClick={() => {
            setSearch("");
            setStatus("all");
            setLevel("all");
            setParent("all");
            setDepartment("all");
          }}
        >
          <Filter size={15} />
          Reset
        </button>
      </section>

      <section className={styles.contentGrid}>
        <div className={styles.tableCard}>
          {categoryFocus ? (
            <div className="rg-filter-chip" role="status">
              <span>Showing sub-heads under: <strong>{categoryFocus}</strong></span>
              <button type="button" onClick={() => setCategoryFocus(null)} aria-label="Clear category filter">✕ Clear</button>
            </div>
          ) : null}
          <div className={styles.cardHeader}>
            <div>
              <h2>
                Finance Subheads ({filtered.length})
              </h2>
            </div>

            <div className={styles.cardActions}>
              <button
                onClick={() =>
                  void exportCsv()
                }
                disabled={exporting}
              >
                <Download size={15} />
                {exporting
                  ? "Exporting…"
                  : "Export CSV"}
              </button>

              <button
                className={styles.iconButton}
                onClick={() =>
                  void load(true)
                }
                disabled={refreshing}
                title="Refresh"
              >
                <RefreshCw
                  size={16}
                  className={
                    refreshing
                      ? styles.spin
                      : ""
                  }
                />
              </button>
            </div>
          </div>

          <div className={styles.tableWrap}>
            <table>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Code</th>
                  <th>Subhead Name</th>
                  <th>Parent Head</th>
                  <th>Level</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Budget (₦)</th>
                  <th>Actions</th>
                </tr>
              </thead>

              <tbody>
                {paged.length === 0 ? (
                  <tr>
                    <td colSpan={9}>
                      <div className={styles.empty}>
                        No finance subheads match the selected filters.
                      </div>
                    </td>
                  </tr>
                ) : (
                  paged.map((item, index) => (
                    <tr key={item.id}>
                      <td>
                        {(safePage - 1) *
                          pageSize +
                          index +
                          1}
                      </td>

                      <td className={styles.codeCell}>
                        {item.code || "—"}
                      </td>

                      <td>
                        <div className={styles.nameCell}>
                          <strong>
                            {item.name}
                          </strong>

                          <small>
                            {item.dept_id
                              ? departmentMap.get(
                                item.dept_id
                              ) || ""
                              : "Institution-wide"}
                          </small>
                        </div>
                      </td>

                      <td className={styles.parentCell}>
                        {getParentLabel(
                          item,
                          byCode
                        )}
                      </td>

                      <td>
                        {subheadLevel(
                          item.code
                        )}
                      </td>

                      <td>
                        Operating
                      </td>

                      <td>
                        <span
                          className={`${styles.statusPill} ${item.is_active
                              ? styles.active
                              : styles.inactive
                            }`}
                        >
                          {item.is_active
                            ? "Active"
                            : "Inactive"}
                        </span>
                      </td>

                      <td className={styles.amountCell}>
                        {Number(
                          item.approved_allocation ||
                          0
                        ).toLocaleString(
                          "en-NG"
                        )}
                      </td>

                      <td>
                        <div className={styles.rowActions}>
                          <button
                            onClick={() =>
                              setSelected(
                                item
                              )
                            }
                            title="View"
                          >
                            <Eye size={15} />
                          </button>

                          <button
                            onClick={() =>
                              openEdit(
                                item
                              )
                            }
                            disabled={!canManage}
                            title="Edit"
                          >
                            <Pencil size={15} />
                          </button>

                          <div className={styles.moreMenu}>
                            <button title="More actions">
                              <MoreVertical size={15} />
                            </button>

                            <div className={styles.moreMenuPanel}>
                              <button
                                onClick={() =>
                                  void toggleActive(
                                    item
                                  )
                                }
                                disabled={!canManage}
                              >
                                <Power size={14} />
                                {item.is_active
                                  ? "Deactivate"
                                  : "Activate"}
                              </button>

                              <button
                                onClick={() =>
                                  void removeUnused(
                                    item
                                  )
                                }
                                disabled={!canManage}
                              >
                                <Trash2 size={14} />
                                Delete unused
                              </button>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <div className={styles.pagination}>
            <span>
              Showing{" "}
              {filtered.length
                ? (safePage - 1) *
                pageSize +
                1
                : 0}{" "}
              to{" "}
              {Math.min(
                safePage *
                pageSize,
                filtered.length
              )}{" "}
              of {filtered.length} subheads
            </span>

            <div>
              <button
                onClick={() =>
                  setPage(1)
                }
                disabled={safePage === 1}
              >
                «
              </button>

              <button
                onClick={() =>
                  setPage((current) =>
                    Math.max(
                      1,
                      current - 1
                    )
                  )
                }
                disabled={safePage === 1}
              >
                ‹
              </button>

              {Array.from(
                {
                  length: Math.min(
                    5,
                    totalPages
                  ),
                },
                (_, index) =>
                  index + 1
              ).map((number) => (
                <button
                  key={number}
                  className={
                    safePage === number
                      ? styles.currentPage
                      : ""
                  }
                  onClick={() =>
                    setPage(
                      number
                    )
                  }
                >
                  {number}
                </button>
              ))}

              {totalPages > 5 ? (
                <span>
                  …
                </span>
              ) : null}

              {totalPages > 5 ? (
                <button
                  onClick={() =>
                    setPage(
                      totalPages
                    )
                  }
                >
                  {totalPages}
                </button>
              ) : null}

              <button
                onClick={() =>
                  setPage((current) =>
                    Math.min(
                      totalPages,
                      current + 1
                    )
                  )
                }
                disabled={
                  safePage ===
                  totalPages
                }
              >
                ›
              </button>

              <button
                onClick={() =>
                  setPage(
                    totalPages
                  )
                }
                disabled={
                  safePage ===
                  totalPages
                }
              >
                »
              </button>
            </div>
          </div>
        </div>

        <aside className={styles.sideColumn}>
          <section className={styles.sideCard}>
            <h3>
              Subhead Overview
            </h3>

            <div className={styles.donutRow}>
              <SharedDonut segments={donutSegments} size={200} strokeWidth={34} fluidMax={210} centerLabel="Total" formatTotal={() => String(total)} selected={categoryFocus} onSegmentSelect={setCategoryFocus} />

              <div className={styles.legend}>
                {categoryData.map(
                  (item, index) => {
                    const colors = [
                      "var(--color-chart-1)",
                      "var(--color-chart-2)",
                      "var(--color-chart-3)",
                      "var(--color-chart-4)",
                      "var(--color-chart-8)",
                    ];

                    return (
                      <button type="button" key={item.label} className="admin-v3-legend-btn" aria-pressed={categoryFocus === item.label} onClick={() => setCategoryFocus(categoryFocus === item.label ? null : item.label)}>
                        <span
                          style={{
                            background:
                              colors[index],
                          }}
                        />

                        <b>
                          {item.label}
                        </b>

                        <small>
                          {item.value} (
                          {total
                            ? (
                              (item.value /
                                total) *
                              100
                            ).toFixed(
                              1
                            )
                            : 0}
                          %)
                        </small>
                      </button>
                    );
                  }
                )}
              </div>
            </div>
          </section>

          <section className={styles.sideCard}>
            <h3>
              Quick Actions
            </h3>

            <QuickAction
              icon={<Plus size={16} />}
              tone="blue"
              title="Create New Subhead"
              note="Add a new finance subhead"
              onClick={openCreate}
            />

            <QuickAction
              icon={<FolderKanban size={16} />}
              tone="green"
              title="Manage Parent Heads"
              note="Review top-level budget heads"
              onClick={() => {
                setLevel("1");
                setParent("all");
              }}
            />

            <QuickAction
              icon={<Network size={16} />}
              tone="purple"
              title="View Subhead Hierarchy"
              note="Browse subheads by parent"
              onClick={() => {
                setLevel("all");
                setParent(
                  parentOptions[0]?.code ||
                  "all"
                );
              }}
            />

            <QuickAction
              icon={<WalletCards size={16} />}
              tone="orange"
              title="Budget Allocation"
              note="Allocate budgets to subheads"
              onClick={() =>
                router.push(
                  "/finance/account-ledger"
                )
              }
            />

            <QuickAction
              icon={<Download size={16} />}
              tone="green"
              title="Export Subhead List"
              note="Download finance subheads report"
              onClick={() =>
                void exportCsv()
              }
            />
          </section>

          <section className={styles.noteCard}>
            <div className={styles.noteTitle}>
              <AlertCircle size={18} />
              Important Note
            </div>

            <p>
              Subheads are used for budgeting, reporting and financial control.
            </p>

            <p>
              Changes may affect existing budgets and transactions.
            </p>
          </section>
        </aside>
      </section>

      {selected ? (
        <div
          className={styles.modalBackdrop}
          onMouseDown={() =>
            setSelected(null)
          }
        >
          <div
            className={styles.detailsModal}
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >
            <div className={styles.modalHeader}>
              <div>
                <small>
                  FINANCE SUBHEAD
                </small>

                <h2>
                  {selected.code
                    ? `${selected.code} — `
                    : ""}
                  {selected.name}
                </h2>
              </div>

              <button
                onClick={() =>
                  setSelected(null)
                }
              >
                <X size={18} />
              </button>
            </div>

            <div className={styles.detailGrid}>
              <Detail
                label="Parent Head"
                value={getParentLabel(
                  selected,
                  byCode
                )}
              />

              <Detail
                label="Department"
                value={
                  selected.dept_id
                    ? departmentMap.get(
                      selected.dept_id
                    ) || "—"
                    : "Institution-wide"
                }
              />

              <Detail
                label="IET Bank"
                value={
                  selected.bank_account_id
                    ? bankMap.get(
                      selected.bank_account_id
                    )?.name || "—"
                    : "Not linked"
                }
              />

              <Detail
                label="Level"
                value={String(
                  subheadLevel(
                    selected.code
                  )
                )}
              />

              <Detail
                label="Approved Allocation"
                value={money(
                  selected.approved_allocation
                )}
              />

              <Detail
                label="Reserved"
                value={money(
                  selected.reserved_amount
                )}
              />

              <Detail
                label="Expenditure"
                value={money(
                  selected.expenditure
                )}
              />

              <Detail
                label="Available Balance"
                value={money(
                  selected.balance
                )}
              />

              <Detail
                label="Linked Requests"
                value={String(
                  selected.request_count ||
                  0
                )}
              />

              <Detail
                label="Last Updated"
                value={formatDate(
                  selected.updated_at
                )}
              />
            </div>

            {selected.allocation_note ? (
              <div className={styles.noteBox}>
                <b>
                  Allocation Note
                </b>

                <p>
                  {selected.allocation_note}
                </p>
              </div>
            ) : null}

            <div className={styles.modalFooter}>
              <button
                onClick={() =>
                  setSelected(null)
                }
              >
                Close
              </button>

              {canManage ? (
                <button
                  className={styles.primaryButton}
                  onClick={() => {
                    const item =
                      selected;

                    setSelected(null);

                    openEdit(
                      item
                    );
                  }}
                >
                  <Pencil size={15} />
                  Edit Subhead
                </button>
              ) : null}
            </div>
          </div>
        </div>
      ) : null}

      {formOpen ? (
        <div
          className={styles.modalBackdrop}
          onMouseDown={() => {
            if (!saving) {
              setFormError(null);
              setFormOpen(false);
            }
          }}
        >
          <div
            className={styles.formModal}
            onMouseDown={(event) =>
              event.stopPropagation()
            }
          >
            <div className={styles.modalHeader}>
              <div>
                <small>
                  {editId
                    ? "EDIT FINANCE SUBHEAD"
                    : "NEW FINANCE SUBHEAD"}
                </small>

                <h2>
                  {editId
                    ? "Update Subhead"
                    : "Create New Subhead"}
                </h2>
              </div>

              <button
                onClick={() => {
                  if (!saving) {
                    setFormError(null);
                    setFormOpen(false);
                  }
                }}
              >
                <X size={18} />
              </button>
            </div>

            <div className={styles.formGrid}>
              <label>
                <span>
                  Subhead Code
                </span>

                <input
                  value={formCode}
                  onChange={(event) =>
                    setFormCode(
                      event.target.value
                    )
                  }
                  placeholder="e.g. 1001.01"
                />
              </label>

              <label>
                <span>
                  Subhead Name
                </span>

                <input
                  value={formName}
                  onChange={(event) =>
                    setFormName(
                      event.target.value
                    )
                  }
                  placeholder="Subhead name"
                />
              </label>

              <label>
                <span>
                  Department
                </span>

                <select
                  value={formDept}
                  onChange={(event) =>
                    setFormDept(
                      event.target.value
                    )
                  }
                >
                  <option value="">
                    Institution-wide
                  </option>

                  {departments.map(
                    (item) => (
                      <option
                        key={item.id}
                        value={item.id}
                      >
                        {item.name}
                      </option>
                    )
                  )}
                </select>
              </label>

              <label>
                <span>
                  Funding Bank
                </span>

                <select
                  value={formBank}
                  onChange={(event) => {
                    setFormBank(event.target.value);
                    setFormError(null);
                  }}
                >
                  <option value="">
                    Select IET bank
                  </option>

                  {banks
                    .filter(
                      (item) =>
                        item.is_active !== false
                    )
                    .map(
                      (item) => (
                        <option
                          key={item.id}
                          value={item.id}
                        >
                          {item.code
                            ? `${item.code} — `
                            : ""}
                          {item.name}
                        </option>
                      )
                    )}
                </select>
              </label>

              {formBank ? (() => {
                const selectedBank = bankMap.get(formBank);
                const current = editId ? subheads.find((item) => item.id === editId) : null;
                const reusable = current?.bank_account_id === formBank ? Number(current.approved_allocation || 0) : 0;
                const remaining = Number(selectedBank?.unallocated_balance || 0) + reusable;
                const afterAllocation = remaining - Number(formAllocation || 0);
                return (
                  <div className={styles.balancePanel}>
                    <div><span>Available to allocate</span><strong>{money(remaining)}</strong></div>
                    <div><span>Requested allocation</span><strong>{money(formAllocation)}</strong></div>
                    <div className={afterAllocation < 0 ? styles.balanceNegative : ""}><span>Remaining after save</span><strong>{money(afterAllocation)}</strong></div>
                    <small>{selectedBank?.name || "Selected IET account"} · live unallocated balance</small>
                  </div>
                );
              })() : null}

              <label>
                <span>
                  Approved Allocation (₦)
                </span>

                <input
                  type="number"
                  min="0"
                  value={formAllocation}
                  onChange={(event) => {
                    setFormAllocation(Number(event.target.value || 0));
                    setFormError(null);
                  }}
                />
              </label>

              <label>
                <span>
                  Status
                </span>

                <select
                  value={
                    formActive
                      ? "active"
                      : "inactive"
                  }
                  onChange={(event) =>
                    setFormActive(
                      event.target.value ===
                      "active"
                    )
                  }
                >
                  <option value="active">
                    Active
                  </option>

                  <option value="inactive">
                    Inactive
                  </option>
                </select>
              </label>

              <label className={styles.fullField}>
                <span>
                  Allocation Note
                </span>

                <textarea
                  value={formNote}
                  onChange={(event) =>
                    setFormNote(
                      event.target.value
                    )
                  }
                  placeholder="Purpose or allocation note"
                  rows={3}
                />
              </label>
            </div>

            {formError ? (
              <div className={styles.formError} role="alert">
                <AlertCircle size={17} />
                <div><strong>Unable to save this subhead</strong><span>{formError}</span></div>
              </div>
            ) : null}

            <div className={styles.modalFooter}>
              <button
                onClick={() => {
                  setFormError(null);
                  setFormOpen(false);
                }}
                disabled={saving}
              >
                Cancel
              </button>

              <button
                className={styles.primaryButton}
                onClick={() =>
                  void saveSubhead()
                }
                disabled={saving}
              >
                <Save size={15} />

                {saving
                  ? "Saving…"
                  : editId
                    ? "Update Subhead"
                    : "Create Subhead"}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function Kpi({
  icon,
  tone,
  label,
  value,
  note,
}: {
  icon: React.ReactNode;
  tone:
  | "blue"
  | "green"
  | "orange"
  | "purple";
  label: string;
  value: string;
  note: string;
}) {
  return (
    <article className={styles.kpi}>
      <div
        className={`${styles.kpiIcon} ${styles[tone]}`}
      >
        {icon}
      </div>

      <div>
        <span>
          {label}
        </span>

        <strong
          className={
            styles[
            `${tone}Text`
            ]
          }
        >
          {value}
        </strong>

        <small>
          {note}
        </small>
      </div>
    </article>
  );
}

function FilterField({
  label,
  children,
  grow = false,
}: {
  label: string;
  children: React.ReactNode;
  grow?: boolean;
}) {
  return (
    <label
      className={`${styles.filterField} ${grow
          ? styles.grow
          : ""
        }`}
    >
      <span>
        {label}
      </span>

      {children}
    </label>
  );
}

function QuickAction({
  icon,
  tone,
  title,
  note,
  onClick,
}: {
  icon: React.ReactNode;
  tone:
  | "blue"
  | "green"
  | "purple"
  | "orange";
  title: string;
  note: string;
  onClick: () => void;
}) {
  return (
    <button
      className={styles.quickAction}
      onClick={onClick}
    >
      <span
        className={`${styles.quickIcon} ${styles[tone]}`}
      >
        {icon}
      </span>

      <span>
        <b>
          {title}
        </b>

        <small>
          {note}
        </small>
      </span>

      <span className={styles.chevron}>
        ›
      </span>
    </button>
  );
}

function Detail({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div className={styles.detail}>
      <span>
        {label}
      </span>

      <strong>
        {value}
      </strong>
    </div>
  );
}