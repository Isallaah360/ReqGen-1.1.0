"use client";

import { IconAction, IconActions } from "@/app/components/ui/IconAction";
import { confirmDialog } from "@/lib/dialog";
import { StatTile } from "@/app/components/ui/StatTile";
import AdminNavigation from "@/app/components/admin/AdminNavigation";
import AdminPermissionMatrix from "@/app/components/admin/AdminPermissionMatrix";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

type ReqgenRole = {
  id: string;
  role_key: string;
  role_name: string;
  description: string | null;
  is_system: boolean;
  is_active: boolean;
  requires_signature: boolean;
  sort_order: number;
  created_at: string | null;
  updated_at: string | null;
};

type ProfileMini = {
  id: string;
  role: string | null;
};

type TabKey = "overview" | "active" | "inactive" | "form";

function roleKey(role: string | null | undefined) {
  return (role || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "")
    .replace(/_/g, "");
}

function makeRoleKey(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, 50);
}

function shortDate(d: string | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleDateString();
}

function roleBadgeClass(role: string | null | undefined) {
  const rk = roleKey(role);

  if (rk === "admin") return "border-red-200 bg-red-50 text-red-700";
  if (rk === "auditor") return "border-purple-200 bg-purple-50 text-purple-700";
  if (["account", "accounts", "accountofficer"].includes(rk)) {
    return "border-emerald-200 bg-emerald-50 text-emerald-700";
  }
  if (["director", "hod", "dg", "dinadmin", "registrar", "gensec"].includes(rk)) {
    return "border-blue-200 bg-blue-50 text-blue-700";
  }
  if (["hr", "hrboss", "hrofficer", "hrofficer1", "hrofficer2", "hrofficer3", "registry"].includes(rk)) {
    return "border-amber-200 bg-amber-50 text-amber-700";
  }

  return "border-slate-200 bg-slate-50 text-slate-700";
}

function canonicalRoleName(role: string | null | undefined, key?: string | null) {
  const normalized = roleKey(key || role);
  if (normalized === "deanadmin" || normalized === "dinadmin") return "DIN Admin";
  if (normalized === "registry" || normalized === "registrar") return "Registrar";
  if (normalized === "gensec" || normalized === "generalsecretary") return "General Secretary";
  if (["account", "accounts", "accountofficer"].includes(normalized)) return "Account Officer";
  return String(role || "Staff").trim() || "Staff";
}

function errorMessage(error: unknown) {
  return error instanceof Error ? error.message : "Unknown error";
}

export default function AdminRolesPage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const [me, setMe] = useState<ProfileMini | null>(null);
  const [roles, setRoles] = useState<ReqgenRole[]>([]);
  const [activeTab, setActiveTab] = useState<TabKey>("overview");
  const [formOpen, setFormOpen] = useState(false);
  const [search, setSearch] = useState("");

  const [editId, setEditId] = useState<string | null>(null);
  const [roleName, setRoleName] = useState("");
  const [description, setDescription] = useState("");
  const [requiresSignature, setRequiresSignature] = useState(false);
  const [active, setActive] = useState(true);
  const [sortOrder, setSortOrder] = useState(100);

  const rk = roleKey(me?.role);
  const canManage = rk === "admin";

  const loadAll = useCallback(
    async (options?: { silent?: boolean }) => {
      if (options?.silent) {
        setRefreshing(true);
      } else {
        setLoading(true);
      }

      setMsg(null);

      const { data: auth } = await supabase.auth.getUser();

      if (!auth.user) {
        router.push("/login");
        return;
      }

      const { data: prof, error: profErr } = await supabase
        .from("profiles")
        .select("id,role")
        .eq("id", auth.user.id)
        .maybeSingle();

      if (profErr) {
        setMsg("Failed to load your profile: " + profErr.message);
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const myProfile = (prof || null) as ProfileMini | null;
      setMe(myProfile);

      const myRole = roleKey(myProfile?.role);

      if (myRole !== "admin") {
        setMsg("Access denied. Admin privilege is required to manage roles.");
        setRoles([]);
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const { data, error } = await supabase
        .from("reqgen_roles")
        .select(
          "id,role_key,role_name,description,is_system,is_active,requires_signature,sort_order,created_at,updated_at"
        )
        .order("sort_order", { ascending: true })
        .order("role_name", { ascending: true });

      if (error) {
        setMsg("Failed to load roles: " + error.message);
        setRoles([]);
      } else {
        setRoles((data || []) as ReqgenRole[]);
      }

      setLoading(false);
      setRefreshing(false);
    },
    [router]
  );

  useEffect(() => {
    const initialTimer = window.setTimeout(() => { void loadAll(); }, 0);

    const refreshOnFocus = () => {
      loadAll({ silent: true });
    };

    const refreshOnVisible = () => {
      if (document.visibilityState === "visible") {
        loadAll({ silent: true });
      }
    };

    window.addEventListener("focus", refreshOnFocus);
    document.addEventListener("visibilitychange", refreshOnVisible);

    return () => {
      window.clearTimeout(initialTimer);
      window.removeEventListener("focus", refreshOnFocus);
      document.removeEventListener("visibilitychange", refreshOnVisible);
    };
  }, [loadAll]);

  const stats = useMemo(() => {
    const total = roles.length;
    const activeCount = roles.filter((r) => r.is_active).length;
    const inactiveCount = roles.filter((r) => !r.is_active).length;
    const systemCount = roles.filter((r) => r.is_system).length;
    const customCount = roles.filter((r) => !r.is_system).length;
    const signatureCount = roles.filter((r) => r.requires_signature).length;

    return {
      total,
      activeCount,
      inactiveCount,
      systemCount,
      customCount,
      signatureCount,
    };
  }, [roles]);

  const filteredRoles = useMemo(() => {
    const s = search.trim().toLowerCase();

    return roles.filter((r) => {
      if (activeTab === "active" && !r.is_active) return false;
      if (activeTab === "inactive" && r.is_active) return false;

      if (!s) return true;

      const haystack = [
        r.role_key,
        r.role_name,
        r.description,
        r.is_system ? "system" : "custom",
        r.is_active ? "active" : "inactive",
        r.requires_signature ? "signature required" : "no signature",
      ]
        .join(" ")
        .toLowerCase();

      return haystack.includes(s);
    });
  }, [roles, search, activeTab]);

  function resetForm() {
    setEditId(null);
    setRoleName("");
    setDescription("");
    setRequiresSignature(false);
    setActive(true);
    setSortOrder(100);
    setFormOpen(false);
  }

  function startCreate() {
    resetForm();
    setMsg(null);
    setFormOpen(true);
  }

  function startEdit(role: ReqgenRole) {
    setEditId(role.id);
    setRoleName(canonicalRoleName(role.role_name, role.role_key));
    setDescription(role.description || "");
    setRequiresSignature(Boolean(role.requires_signature));
    setActive(Boolean(role.is_active));
    setSortOrder(Number(role.sort_order || 100));
    setMsg(null);
    setFormOpen(true);
  }

  async function saveRole() {
    if (!canManage) {
      setMsg("✕ Not allowed.");
      return;
    }

    const name = roleName.trim();
    const desc = description.trim();
    const key = makeRoleKey(name);

    if (name.length < 2) {
      setMsg("✕ Role name is required.");
      return;
    }

    if (key.length < 2) {
      setMsg("✕ Role key could not be generated. Use letters and numbers.");
      return;
    }

    const existing = roles.find((r) => roleKey(r.role_name) === roleKey(name) && r.id !== editId);

    if (existing) {
      setMsg("✕ A role with this name already exists.");
      return;
    }

    setSaving(true);
    setMsg(null);

    try {
      if (!editId) {
        const payload = {
          role_key: key,
          role_name: name,
          description: desc || null,
          is_system: false,
          is_active: active,
          requires_signature: requiresSignature,
          sort_order: Number(sortOrder || 100),
        };

        const { error } = await supabase.from("reqgen_roles").insert(payload);

        if (error) throw new Error(error.message);

        setMsg("✓ Role created successfully.");
      } else {
        const current = roles.find((r) => r.id === editId);

        if (!current) {
          throw new Error("Selected role not found.");
        }

        const payload: Partial<ReqgenRole> = {
          role_name: name,
          description: desc || null,
          is_active: active,
          requires_signature: requiresSignature,
          sort_order: Number(sortOrder || 100),
        };

        if (!current.is_system) {
          payload.role_key = key;
        }

        const { error } = await supabase
          .from("reqgen_roles")
          .update(payload)
          .eq("id", editId);

        if (error) throw new Error(error.message);

        setMsg("✓ Role updated successfully.");
      }

      resetForm();
      setActiveTab(active ? "active" : "inactive");
      await loadAll({ silent: true });
      router.refresh();
    } catch (e: unknown) {
      setMsg("✕ Save failed: " + errorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  async function toggleActive(role: ReqgenRole, nextActive: boolean) {
    if (!canManage) {
      setMsg("✕ Not allowed.");
      return;
    }

    const ok = await confirmDialog({
      title: nextActive ? "Activate role?" : "Deactivate role?",
      message: `Set role "${canonicalRoleName(role.role_name, role.role_key)}" to ${nextActive ? "Active" : "Inactive"}?`,
      confirmLabel: nextActive ? "Activate" : "Deactivate",
      tone: nextActive ? "default" : "warning",
    });

    if (!ok) return;

    setSaving(true);
    setMsg(null);

    try {
      const { error } = await supabase
        .from("reqgen_roles")
        .update({ is_active: nextActive })
        .eq("id", role.id);

      if (error) throw new Error(error.message);

      setMsg(nextActive ? "✓ Role activated." : "✓ Role deactivated.");
      await loadAll({ silent: true });
      router.refresh();
    } catch (e: unknown) {
      setMsg("✕ Failed: " + errorMessage(e));
    } finally {
      setSaving(false);
    }
  }

  async function deleteRole(role: ReqgenRole) {
    if (!canManage) {
      setMsg("✕ Not allowed.");
      return;
    }

    if (role.is_system) {
      setMsg("✕ System roles cannot be deleted. Deactivate if necessary.");
      return;
    }

    const ok = await confirmDialog({
      title: "Delete custom role?",
      message: `Delete custom role "${canonicalRoleName(role.role_name, role.role_key)}" permanently?`,
      details: ["Only unused custom roles should be deleted."],
      confirmLabel: "Delete role",
      tone: "danger",
    });

    if (!ok) return;

    setSaving(true);
    setMsg(null);

    try {
      const { error } = await supabase.from("reqgen_roles").delete().eq("id", role.id);

      if (error) throw new Error(error.message);

      setMsg("✓ Custom role deleted successfully.");

      if (editId === role.id) {
        resetForm();
      }

      await loadAll({ silent: true });
      router.refresh();
    } catch (e: unknown) {
      setMsg(
        "✕ Delete failed: " +
          errorMessage(e) +
          ". If the role is already in use, deactivate it instead."
      );
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-transparent px-4" data-rg-standard="phase7">
        <div className="mx-auto max-w-7xl py-10 text-slate-600">
          Loading roles...
        </div>
      </main>
    );
  }

  if (!canManage) {
    return (
      <main className="min-h-screen bg-transparent px-4" data-rg-standard="phase7">
        <div className="mx-auto max-w-3xl py-10">
          <div className="rounded-3xl border bg-white p-6 shadow-sm">
            <h1 className="text-xl font-extrabold text-slate-900">Access denied</h1>
            <p className="mt-2 text-sm text-slate-600">
              Only Admin/Auditor can manage roles and permissions.
            </p>

            {msg && (
              <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-900">
                {msg}
              </div>
            )}

            <button
              onClick={() => router.push(`/dashboard?updated=${Date.now()}`)}
              className="reqgen-btn reqgen-btn-blue mt-5 rounded-xl px-4 py-2 text-sm font-black text-white"
            >
              Back to Dashboard
            </button>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-transparent px-4" data-rg-standard="phase7">
      <AdminNavigation />
      <div className="mx-auto max-w-7xl py-5">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight text-slate-900">
              Roles & Permissions
            </h1>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => loadAll({ silent: true })}
              disabled={refreshing || saving}
              className="rg-btn rg-btn-secondary"
            >
              {refreshing ? "Refreshing..." : "Refresh"}
            </button>

            <button
              onClick={startCreate}
              disabled={refreshing || saving}
              className="rg-btn rg-btn-primary"
            >
              Add Role
            </button>

          </div>
        </div>

        {msg && (
          <div className="mt-4 rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-800 shadow-sm">
            {msg}
          </div>
        )}

        <div className="mt-4 rounded-xl border border-blue-100 bg-blue-50 px-4 py-3 text-xs font-semibold text-blue-900">
          System roles are protected. They can be edited or deactivated where necessary, but cannot be permanently deleted.
        </div>

        <AdminPermissionMatrix />

        <div className="mt-6 rg-auto-grid rg-auto-grid-6">
          <StatCard title="Total Roles" value={String(stats.total)} tone="blue" note="In the role catalogue" />
          <StatCard title="Active" value={String(stats.activeCount)} tone="emerald" note="Assignable to users" />
          <StatCard title="Inactive" value={String(stats.inactiveCount)} tone="amber" note="Retained for history" />
          <StatCard title="System Roles" value={String(stats.systemCount)} tone="purple" note="Protected built-in roles" />
          <StatCard title="Custom Roles" value={String(stats.customCount)} tone="slate" note="Created by Admin" />
          <StatCard title="Signature Required" value={String(stats.signatureCount)} tone="red" note="Roles needing a signature" />
        </div>

        <div className="mt-5 rounded-xl border bg-white p-1 shadow-sm" data-rg-tabs="true">
          <div className="flex flex-wrap gap-1">
            <TabButton label="Overview" active={activeTab === "overview"} onClick={() => setActiveTab("overview")} />
            <TabButton label="Active Roles" active={activeTab === "active"} onClick={() => setActiveTab("active")} />
            <TabButton label="Inactive Roles" active={activeTab === "inactive"} onClick={() => setActiveTab("inactive")} />
          </div>
        </div>

        {(activeTab === "overview" || activeTab === "active" || activeTab === "inactive") && (
          <div className="mt-5 rounded-xl border bg-white p-4 shadow-sm">
            <label className="text-xs font-extrabold text-slate-700">Search Roles</label>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search role name, key, description, status..."
              className="mt-1 h-10 w-full rounded-lg border border-slate-200 px-3 text-sm text-slate-900 outline-none focus:border-blue-500"
            />
          </div>
        )}

        {formOpen && (
          <div className="rg-modal-backdrop" role="presentation" onMouseDown={() => !saving && resetForm()}>
          <div className="rg-modal" role="dialog" aria-modal="true" aria-label={editId ? "Edit role" : "Add new role"} onMouseDown={(event) => event.stopPropagation()}>
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-lg font-bold text-slate-900">
                  {editId ? "Edit Role" : "Add New Role"}
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Create or update a role used by the Admin user assignment page.
                </p>
              </div>

              {(
                <button
                  onClick={resetForm}
                  disabled={saving}
                  className="reqgen-btn reqgen-btn-orange rounded-xl border border-slate-200 px-4 py-2 text-sm disabled:opacity-60 font-black text-white"
                >
                  Cancel
                </button>
              )}
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2">
              <div>
                <label className="text-sm font-semibold text-slate-800">Role Name</label>
                <input
                  value={roleName}
                  onChange={(e) => setRoleName(e.target.value)}
                  disabled={saving}
                  placeholder="e.g. DINAdmin"
                  className="mt-1 w-full rounded-2xl border border-slate-200 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 disabled:bg-slate-50"
                />
                <div className="mt-1 text-xs font-semibold text-slate-500">
                  Generated key: {makeRoleKey(roleName) || "—"}
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-slate-800">Sort Order</label>
                <input
                  value={sortOrder}
                  onChange={(e) => setSortOrder(Number(e.target.value || 100))}
                  disabled={saving}
                  type="number"
                  className="mt-1 w-full rounded-2xl border border-slate-200 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 disabled:bg-slate-50"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-sm font-semibold text-slate-800">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  disabled={saving}
                  placeholder="Briefly describe what this role does..."
                  className="mt-1 min-h-[110px] w-full rounded-2xl border border-slate-200 px-4 py-3 text-slate-900 outline-none focus:border-blue-500 disabled:bg-slate-50"
                />
              </div>

              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <label className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800">
                  <input
                    type="checkbox"
                    checked={requiresSignature}
                    onChange={(e) => setRequiresSignature(e.target.checked)}
                    disabled={saving}
                  />
                  Requires Signature
                </label>
                <p className="mt-2 text-xs text-slate-600">
                  Use this for workflow-sensitive roles such as Director, HOD, DG, HR, Auditor, Admin and AccountOfficer.
                </p>
              </div>

              <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <label className="inline-flex items-center gap-2 text-sm font-semibold text-slate-800">
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={(e) => setActive(e.target.checked)}
                    disabled={saving}
                  />
                  Active
                </label>
                <p className="mt-2 text-xs text-slate-600">
                  Inactive roles will not appear in user role assignment dropdowns.
                </p>
              </div>
            </div>

            <button
              onClick={saveRole}
              disabled={saving}
              className="reqgen-btn reqgen-btn-emerald mt-5 w-full rounded-2xl px-4 py-3 text-sm font-black text-white disabled:opacity-60"
            >
              {saving ? "Saving..." : editId ? "Update Role" : "Create Role"}
            </button>
          </div>
          </div>
        )}

        {(activeTab === "overview" || activeTab === "active" || activeTab === "inactive") && (
          <div className="mt-5 overflow-hidden rounded-xl border bg-white shadow-sm">
            <div className="border-b bg-slate-50 px-4 py-3">
              <h2 className="text-sm font-extrabold text-slate-900">Role Register</h2>
              <p className="mt-1 text-xs text-slate-600">
                System and custom roles available for ReqGen user assignment.
              </p>
            </div>

            {filteredRoles.length === 0 ? (
              <div className="p-6 text-sm text-slate-700">No roles found.</div>
            ) : (
              <>
                <div className="grid gap-4 p-4 xl:hidden">
                  {filteredRoles.map((role) => (
                    <RoleCard
                      key={role.id}
                      role={role}
                      saving={saving}
                      onEdit={() => startEdit(role)}
                      onToggle={() => toggleActive(role, !role.is_active)}
                      onDelete={() => deleteRole(role)}
                    />
                  ))}
                </div>

                <div className="hidden overflow-x-auto xl:block">
                  <table className="w-full table-fixed border-collapse text-sm" data-rg-table="standard">
                    <thead>
                      <tr className="bg-slate-100 text-xs uppercase tracking-wide text-slate-600">
                        <th className="px-4 py-3 text-left">Role</th>
                        <th className="px-4 py-3 text-left">Key</th>
                        <th className="w-[28%] px-4 py-3 text-left">Description</th>
                        <th className="px-4 py-3 text-left">Type</th>
                        <th className="px-4 py-3 text-left">Signature</th>
                        <th className="px-4 py-3 text-left">Status</th>
                        <th className="px-4 py-3 text-left">Updated</th>
                        <th className="w-[230px] px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>

                    <tbody>
                      {filteredRoles.map((role) => (
                        <tr key={role.id} className="border-t hover:bg-slate-50">
                          <td className="px-4 py-4">
                            <span
                              className={`inline-flex rounded-full border px-3 py-1 text-xs font-bold ${roleBadgeClass(
                                role.role_name
                              )}`}
                            >
                              {canonicalRoleName(role.role_name, role.role_key)}
                            </span>
                          </td>

                          <td className="px-4 py-4 font-mono text-xs font-bold text-slate-700">
                            {role.role_key}
                          </td>

                          <td className="px-4 py-4 text-slate-700">
                            {role.description || "—"}
                          </td>

                          <td className="px-4 py-4">
                            <span
                              className={`rounded-full border px-3 py-1 text-xs font-bold ${
                                role.is_system
                                  ? "border-purple-200 bg-purple-50 text-purple-700"
                                  : "border-slate-200 bg-slate-50 text-slate-700"
                              }`}
                            >
                              {role.is_system ? "System" : "Custom"}
                            </span>
                          </td>

                          <td className="px-4 py-4">
                            <span
                              className={`rounded-full border px-3 py-1 text-xs font-bold ${
                                role.requires_signature
                                  ? "border-blue-200 bg-blue-50 text-blue-700"
                                  : "border-slate-200 bg-slate-50 text-slate-700"
                              }`}
                            >
                              {role.requires_signature ? "Required" : "Not Required"}
                            </span>
                          </td>

                          <td className="px-4 py-4">
                            <StatusBadge active={role.is_active} />
                          </td>

                          <td className="px-4 py-4 text-slate-600">
                            {shortDate(role.updated_at)}
                          </td>

                          <td className="px-4 py-4">
                            <IconActions>
                              <IconAction kind="edit" label={`Edit ${canonicalRoleName(role.role_name, role.role_key)}`} onClick={() => startEdit(role)} disabled={saving} />
                              <IconAction kind={role.is_active ? "deactivate" : "activate"} label={`${role.is_active ? "Deactivate" : "Activate"} ${canonicalRoleName(role.role_name, role.role_key)}`} onClick={() => toggleActive(role, !role.is_active)} disabled={saving} />
                              <IconAction kind="delete" label={role.is_system ? "System roles cannot be deleted" : `Delete ${canonicalRoleName(role.role_name, role.role_key)}`} onClick={() => deleteRole(role)} disabled={saving || role.is_system} />
                            </IconActions>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </>
            )}
          </div>
        )}

      </div>
    </main>
  );
}

function RoleCard({
  role,
  saving,
  onEdit,
  onToggle,
  onDelete,
}: {
  role: ReqgenRole;
  saving: boolean;
  onEdit: () => void;
  onToggle: () => void;
  onDelete: () => void;
}) {
  return (
    <div className="rounded-3xl border bg-white p-5 shadow-sm">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <span className={`inline-flex rounded-full border px-3 py-1 text-xs font-bold ${roleBadgeClass(role.role_name)}`}>
            {canonicalRoleName(role.role_name, role.role_key)}
          </span>
          <div className="mt-2 font-mono text-xs font-bold text-slate-500">
            {role.role_key}
          </div>
        </div>

        <StatusBadge active={role.is_active} />
      </div>

      <p className="mt-4 text-sm text-slate-700">
        {role.description || "No description supplied."}
      </p>

      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        <InfoMetric title="Type" value={role.is_system ? "System" : "Custom"} />
        <InfoMetric title="Signature" value={role.requires_signature ? "Required" : "Not Required"} />
        <InfoMetric title="Updated" value={shortDate(role.updated_at)} />
      </div>

      <div className="mt-4 flex justify-end">
        <IconActions>
          <IconAction kind="edit" label="Edit role" onClick={onEdit} disabled={saving} />
          <IconAction kind={role.is_active ? "deactivate" : "activate"} label={role.is_active ? "Deactivate role" : "Activate role"} onClick={onToggle} disabled={saving} />
          <IconAction kind="delete" label={role.is_system ? "System roles cannot be deleted" : "Delete role"} onClick={onDelete} disabled={saving || role.is_system} />
        </IconActions>
      </div>
    </div>
  );
}

function StatusBadge({ active }: { active: boolean }) {
  return (
    <span
      className={`rounded-full border px-3 py-1 text-xs font-bold ${
        active
          ? "border-emerald-200 bg-emerald-50 text-emerald-700"
          : "border-red-200 bg-red-50 text-red-700"
      }`}
    >
      {active ? "Active" : "Inactive"}
    </span>
  );
}

function InfoMetric({ title, value }: { title: string; value: string }) {
  return (
    <div className="rounded-2xl bg-slate-50 p-3">
      <div className="text-xs font-semibold uppercase tracking-wide text-slate-500">
        {title}
      </div>
      <div className="mt-2 text-sm font-extrabold text-slate-900">{value}</div>
    </div>
  );
}

function TabButton({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`reqgen-btn rounded-2xl px-4 py-3 text-sm font-black text-white transition ${active ? "reqgen-btn-blue ring-4 ring-blue-100" : "reqgen-btn-slate"}`}
    >
      {label}
    </button>
  );
}

function StatCard({
  title,
  value,
  tone, note }: {
  title: string;
  value: string;
  tone: "blue" | "emerald" | "amber" | "purple" | "slate" | "red"; note?: string }) {
  return <StatTile title={String(title)} value={value} tone={tone} note={note} />;
}
