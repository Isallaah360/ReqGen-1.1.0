"use client";

import AdminNavigation from "@/app/components/admin/AdminNavigation";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

type DepartmentRow = { id: string; name: string; hod_user_id: string | null; director_user_id: string | null };
type UserRow = { id: string; email: string | null; role: string | null };

export default function DepartmentsPage() {

  const [departments, setDepartments] = useState<DepartmentRow[]>([]);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [msg,setMsg] = useState("");

  async function loadData() {

    const { data: dept } = await supabase
      .from("departments")
      .select("*")
      .order("name");

    const { data: users } = await supabase
      .from("profiles")
      .select("id,email,role");

    setDepartments((dept || []) as DepartmentRow[]);
    setUsers((users || []) as UserRow[]);
  }

  useEffect(()=>{
    queueMicrotask(() => { void loadData(); });
  },[])

  async function saveDept(dept: DepartmentRow){

    const { error } = await supabase
      .from("departments")
      .update({
        hod_user_id: dept.hod_user_id,
        director_user_id: dept.director_user_id
      })
      .eq("id",dept.id)

    if(error){
      setMsg(error.message)
      return
    }

    setMsg("Department routing updated")
  }

  return (

    <main className="max-w-5xl mx-auto py-10">
      <AdminNavigation />

      <h1 className="text-2xl font-bold mb-6">
        Department Routing
      </h1>

      {msg && (
        <div className="mb-4 text-red-600">{msg}</div>
      )}

      {departments.map((dept)=>{

        return(

          <div
          key={dept.id}
          className="border rounded-xl p-5 mb-5 bg-white">

            <h2 className="font-bold mb-3">
              {dept.name}
            </h2>

            <div className="grid grid-cols-2 gap-4">

              {/* HOD */}

              <div>

                <label className="text-sm">HOD</label>

                <select
                value={dept.hod_user_id || ""}
                onChange={(e)=>{

                  setDepartments(prev =>
                    prev.map(d =>
                      d.id === dept.id
                      ? {...d, hod_user_id:e.target.value}
                      : d
                    )
                  )

                }}
                className="w-full border p-2 rounded">

                  <option value="">None</option>

                  {users.map((u)=>(
                    <option key={u.id} value={u.id}>
                      {u.email} ({u.role})
                    </option>
                  ))}

                </select>

              </div>


              {/* DIRECTOR */}

              <div>

                <label className="text-sm">Director</label>

                <select
                value={dept.director_user_id || ""}
                onChange={(e)=>{

                  setDepartments(prev =>
                    prev.map(d =>
                      d.id === dept.id
                      ? {...d, director_user_id:e.target.value}
                      : d
                    )
                  )

                }}
                className="w-full border p-2 rounded">

                  <option value="">None</option>

                  {users.map((u)=>(
                    <option key={u.id} value={u.id}>
                      {u.email} ({u.role})
                    </option>
                  ))}

                </select>

              </div>

            </div>

            <button
            onClick={()=>saveDept(dept)}
            className="reqgen-btn reqgen-btn-emerald mt-4 rounded-xl px-4 py-2 font-black text-white">

              Save

            </button>

          </div>

        )

      })}

    </main>
  );
}